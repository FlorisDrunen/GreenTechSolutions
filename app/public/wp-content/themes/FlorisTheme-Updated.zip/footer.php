
<footer>
<?php wp_footer(); ?>
</footer>
</body>
</html>